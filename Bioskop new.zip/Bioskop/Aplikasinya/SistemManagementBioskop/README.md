APLIKASI BOOKSKOP
Fachri - Abdullah - Matahari

Applikasi Booking Bioskop Berbasis Desktop dengan Java
•	Aplikasi ini untuk mempermudah pengguna untuk memesan tiket tanpa harus antri di bioskop / kehabisan tiket, aplikasi ini memiliki beberapa fitur yaitu :
-	Pesan tiket *as user
-	Role Staff
-	Role Admin
-	Lihat daftar film *as user
-	Lihat film
-	Lihat Pelanggan
-	Lihat Studio
-	Lihat Bioskop
-	Tambah User
-	Reset Bangku
Kemudian Setiap Staff hanya bisa buka panel sesuai tugas nya kecuali super staff (admin)
Role Staff :
1 = Staff ruang studio, hanya bisa mengedit Studio
2 = Staff Bioskop, hanya bisa mengedit Bioskop
3 = Staff data Pelanggan, hanya bisa mengedit Data Pelanggan
4 = Staff Film, hanya bisa mengedit data film
5 = Super Staff, mampu mengedit semua dan menambah User Staff baru










2.	User Manual :
1.	Halaman Utama User, kemudian ada 3 button :
-	Pesan Tiket
-	Lihat Daftar Film
-	Staff Login











2.	Halaman Pesan Tiket
Di halaman ini kita bisa memesan tiket bioskop dengan mengisi form yang sudah di sediakan, kemudian pilih tempat duduk dan tekan tombol pesan untuk pesan tiketnya.


















3.	Halaman Lihat Daftar Film
Pada halaman ini kita bisa melihat daftar film apa saja yang sedang tayang di bioskop.














4.	Halaman Login Admin dan Staff
Pada halama ini kita bisa masuk menjadi admin dan staff












5.	Halaman Staff Mode
Pada halaman staff mode ini akan menampilkan 4 fitur yaitu :
-	Edit Film
-	Edit Studio
-	Edit Bioskop
-	Edit Pelanggan












6.	Halaman Staff Mode Film
Pada halaman ini staff yang bertugas bisa membuat jadwal film baru yang akan tayang ada jadwal selanjutnya kemudian staff juga dapat mengedit dan menghapus jadwal film yang sudah dibuat.

















7.	Halaman Staff Mode Studio
Pada halaman ini staff bisa menambahkan, menyimpan, mengedit dan menghapus studio.



















8.	Halaman Staff Mode Bioskop
Pada halaman ini staff bisa mengatur nama bioskop, alamat, daerah, nomor studio, kemudian menghapus, mengedit dan menyimpannya.















9.	Halaman Staff Mode Pelanggan
Pada halaman ini staff bisa mengedit dan menyimpan data pelanggan yang sudah tersimpan di database.





















10.	Tambah User
Pada halaman ini admin dapat menambahkan staff yang akan bertugas.














11.	Reset Bangku
Pada halaman ini fitur reset bangku untuk reset bangku studio setelah film selesai.
